package com.medilab.schedule.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.medilab.schedule.bean.MedilabDoctorsScheduleBean;
import com.medilab.schedule.domain.MedilabDoctorsSchedule;

public interface DoctorsScheduleRepo extends JpaRepository<MedilabDoctorsSchedule, Long> {

}
