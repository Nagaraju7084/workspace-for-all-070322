package com.medilab.schedule;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.medilab.schedule.bean.DaysEnum;
import com.medilab.schedule.domain.DoctorsAvailableDays;
import com.medilab.schedule.repository.DoctorsAvailbeDaysRepo;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class DoctorsAvailableDaysLoader implements CommandLineRunner {

	@Autowired
	private DoctorsAvailbeDaysRepo daysRepo;
	
	@Override
	public void run(String... args) throws Exception {
		List<DoctorsAvailableDays> daysList = new ArrayList<>();
		log.info("doctors available days data is loading start....");
		DoctorsAvailableDays sunday = new DoctorsAvailableDays(DaysEnum.SUNDAY.getId(), DaysEnum.SUNDAY.getDay());
		daysList.add(sunday);
		DoctorsAvailableDays monday = new DoctorsAvailableDays(DaysEnum.MONDAY.getId(), DaysEnum.MONDAY.getDay());
		daysList.add(monday);
		DoctorsAvailableDays tuesday = new DoctorsAvailableDays(DaysEnum.TUESDAY.getId(), DaysEnum.TUESDAY.getDay());
		daysList.add(tuesday);
		DoctorsAvailableDays wedday = new DoctorsAvailableDays(DaysEnum.WEDNESSDAY.getId(), DaysEnum.WEDNESSDAY.getDay());
		daysList.add(wedday);
		DoctorsAvailableDays thurday = new DoctorsAvailableDays(DaysEnum.THURSDAY.getId(), DaysEnum.THURSDAY.getDay());
		daysList.add(thurday);
		DoctorsAvailableDays friday = new DoctorsAvailableDays(DaysEnum.FRIDAY.getId(), DaysEnum.FRIDAY.getDay());
		daysList.add(friday);
		DoctorsAvailableDays satday = new DoctorsAvailableDays(DaysEnum.SATDAY.getId(), DaysEnum.SATDAY.getDay());
		daysList.add(satday);
		
		daysRepo.saveAll(daysList);
		log.info("doctors available days data is loading end....");

	}

}
