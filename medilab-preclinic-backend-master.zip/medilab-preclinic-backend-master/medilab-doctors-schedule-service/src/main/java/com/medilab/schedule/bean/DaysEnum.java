/**
 * 
 */
package com.medilab.schedule.bean;

import java.util.Arrays;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author IM-LP-1763
 *
 */
//@Entity
//@Table(name = "dotcors-available-days")
public enum DaysEnum {

	SUNDAY(1,"Sunday"),
	MONDAY(2,"Monday"),
	TUESDAY(3,"Tuesday"),
	WEDNESSDAY(4,"Wednessday"),
	THURSDAY(5,"Tursday"),
	FRIDAY(6,"Friday"),
	SATDAY(7,"Saturday");
	
	@Id
	private int id;
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	private String day;
	
	DaysEnum(int id, String day){
		this.id = id;
		this.day = day;
	}
	
	/*
	 * public static List<DaysEnum> findAllDays(){ return
	 * Arrays.asList(DaysEnum.values()); }
	 */
	
}
