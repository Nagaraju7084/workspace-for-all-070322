package com.medilab.schedule.bean;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.AssertFalse;
import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotEmpty;

import lombok.Data;

/**
 * 
 * @author Narsi
 * @since 29-Nov-2021
 * @apiNote
 *
 */
@Data
public class MedilabDoctorsScheduleBean implements Serializable {/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private long scheduleId;

	
	@NotEmpty(message = "Doctor Name must be selected. it should be have some value")
	private String doctorName;

	@Valid
	private List<DoctorsAvailableDaysBean> availableDays;
	
	/**
	 * "dd/MM/yyyy HH:mm" 
	 */
	@NotEmpty(message = "Start Time must be Provided. it should be have some value")
	private String startTime;
	
	/**
	 * "dd/MM/yyyy HH:mm" 
	 */
	@NotEmpty(message = "End Time must be Provided. it should be have some value")
	private String endTime;
	
	private String message;
	
	//@AssertFalse(message = "schedule status value either must be false")
	//@AssertTrue(message = "schedule status value must be eiather true or false ")
	private boolean scheduleStatus=true;

}
