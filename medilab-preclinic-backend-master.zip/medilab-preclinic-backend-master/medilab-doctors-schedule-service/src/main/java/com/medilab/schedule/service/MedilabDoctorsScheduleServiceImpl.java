package com.medilab.schedule.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.medilab.schedule.bean.MedilabDoctorsScheduleBean;
import com.medilab.schedule.domain.DoctorsAvailableDays;
import com.medilab.schedule.domain.MedilabDoctorsSchedule;
import com.medilab.schedule.exception.AvailableDaysException;
import com.medilab.schedule.exception.DoctorScheduleException;
import com.medilab.schedule.repository.DoctorsAvailbeDaysRepo;
import com.medilab.schedule.repository.DoctorsScheduleRepo;

@Service
public class MedilabDoctorsScheduleServiceImpl implements MedilabDoctorsScheduleService {

	@Autowired
	private DoctorsScheduleRepo scheduleRepo;
	
	@Autowired
	private DoctorsAvailbeDaysRepo doctorsAvailableRepo;
	
	@Override
	public MedilabDoctorsScheduleBean createDoctorSchedule(MedilabDoctorsScheduleBean scheduleBean) {
		MedilabDoctorsSchedule scheduleDomain = new MedilabDoctorsSchedule();
		BeanUtils.copyProperties(scheduleBean, scheduleDomain);
		if(scheduleBean.getAvailableDays() != null && scheduleBean.getAvailableDays().size() >0) {
			List<DoctorsAvailableDays> availableDaysList = new ArrayList<>();
			scheduleBean.getAvailableDays().stream().forEach(availableDayBean->{
				//DoctorsAvailableDays availDaysDomain = doctorsAvailableRepo.findById(availableDayBean.getId()).get();
				//DoctorsAvailableDays availDaysDomain = new DoctorsAvailableDays();
				Optional<DoctorsAvailableDays> optionalDays = doctorsAvailableRepo.findById(availableDayBean.getId());
				if(!optionalDays.isPresent()) {
					throw new AvailableDaysException(HttpStatus.NOT_FOUND.value(), "No Day found with the give Id", new Date());
				}
				DoctorsAvailableDays availDaysDomain =  optionalDays.get();
				BeanUtils.copyProperties(availableDayBean, availDaysDomain);
				availableDaysList.add(availDaysDomain);
			});
			scheduleDomain.setAvailableDays(availableDaysList);
		}
		
		try {
			scheduleRepo.save(scheduleDomain);
			BeanUtils.copyProperties(scheduleDomain, scheduleBean);
		}catch (Exception e) {
			if(e instanceof DataIntegrityViolationException) {
				String message ="Data is duplicated or not in database acceptible format";
				System.out.println(message);
				/*
				 * for(StackTraceElement ste: e.getStackTrace()) {
				 * System.out.println(ste.toString()); System.out.println(ste.getFileName()); }
				 */
				throw new DoctorScheduleException(HttpStatus.NOT_ACCEPTABLE.value(),message,new Date());
			}
			throw new DoctorScheduleException(HttpStatus.INTERNAL_SERVER_ERROR.value(),e.getLocalizedMessage(),new Date());
		}
		
		return scheduleBean;
	}

	@Override
	public MedilabDoctorsScheduleBean updateDoctorSchedule(MedilabDoctorsScheduleBean scheduleBean) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<MedilabDoctorsScheduleBean> findAllDoctorSchedule() {
		// TODO Auto-generated method stub
		return null;
	}

}
