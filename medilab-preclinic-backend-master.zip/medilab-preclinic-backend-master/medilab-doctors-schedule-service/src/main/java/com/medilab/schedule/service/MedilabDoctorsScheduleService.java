package com.medilab.schedule.service;

import java.util.List;

import com.medilab.schedule.bean.MedilabDoctorsScheduleBean;

public interface MedilabDoctorsScheduleService {

	MedilabDoctorsScheduleBean createDoctorSchedule(MedilabDoctorsScheduleBean scheduleBean);
	MedilabDoctorsScheduleBean updateDoctorSchedule(MedilabDoctorsScheduleBean scheduleBean);
	List<MedilabDoctorsScheduleBean> findAllDoctorSchedule();
}
