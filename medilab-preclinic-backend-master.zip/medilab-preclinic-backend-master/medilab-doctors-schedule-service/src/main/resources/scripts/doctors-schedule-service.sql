CREATE SCHEMA `doctors-schedule-service` ;
