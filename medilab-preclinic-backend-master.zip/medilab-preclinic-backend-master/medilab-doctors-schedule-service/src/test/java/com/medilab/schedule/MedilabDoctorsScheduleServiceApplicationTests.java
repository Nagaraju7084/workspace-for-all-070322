package com.medilab.schedule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedilabDoctorsScheduleServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
