package com.medilab.preclinic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedilabUserManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedilabUserManagementApplication.class, args);
	}

}
